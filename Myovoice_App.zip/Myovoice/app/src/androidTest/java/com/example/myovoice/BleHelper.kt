package com.example.myovoice // CHECK THIS PACKAGE NAME!

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.*

@SuppressLint("MissingPermission") // We assume permissions are handled in Activity
class BleHelper(private val context: Context, private val onDataReceived: (String) -> Unit) {

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var bluetoothGatt: BluetoothGatt? = null

    // UUIDs MUST MATCH YOUR ESP32 CODE
    private val SERVICE_UUID = UUID.fromString("4fafc201-1fb5-459e-8fcc-c5c9c331914b")
    private val CHAR_UUID = UUID.fromString("beb5483e-36e1-4688-b7f5-ea07361b26a8")

    fun startScan() {
        Log.d("BLE", "Starting Scan...")
        val scanner = bluetoothAdapter?.bluetoothLeScanner
        scanner?.startScan(object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult?) {
                result?.device?.let { device ->
                    // Replace "MYOVOICE" with your ESP32's exact name or allow all
                    if (device.name == "MYOVOICE_GLOVE" || device.name == "ESP32_Command_Center") {
                        Log.d("BLE", "Device Found: ${device.name}")
                        scanner.stopScan(this) // Stop scanning once found
                        connectToDevice(device)
                    }
                }
            }
        })
    }

    private fun connectToDevice(device: BluetoothDevice) {
        bluetoothGatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    Log.d("BLE", "Connected! Discovering Services...")
                    gatt?.discoverServices()
                }
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
                val characteristic = gatt?.getService(SERVICE_UUID)?.getCharacteristic(CHAR_UUID)
                if (characteristic != null) {
                    gatt.setCharacteristicNotification(characteristic, true)

                    // Enable Notifications on the ESP32 side (Descriptor Write)
                    val descriptor = characteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                    descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    gatt.writeDescriptor(descriptor)
                    Log.d("BLE", "Listening for Data...")
                }
            }

            override fun onCharacteristicChanged(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?) {
                characteristic?.value?.let { bytes ->
                    val hexString = "0x" + bytes.joinToString("") { "%02X".format(it) }
                    // Send to Main Thread
                    Handler(Looper.getMainLooper()).post {
                        onDataReceived(hexString)
                    }
                }
            }
        })
    }
}