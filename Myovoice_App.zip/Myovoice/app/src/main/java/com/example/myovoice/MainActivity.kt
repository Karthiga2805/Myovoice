package com.example.myovoice // Make sure this matches your folder!

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Ask to ignore battery optimization (Keeps Bluetooth alive in pocket)
        val pm = getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
        val packageName = packageName
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val intent = android.content.Intent()
            intent.action = android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
            intent.data = android.net.Uri.parse("package:$packageName")
            startActivity(intent)
        }
    }
}