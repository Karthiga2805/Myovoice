package com.example.myovoice

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.*

@SuppressLint("MissingPermission")
class BleHelper(
    private val context: Context,
    private val onDataReceived: (String) -> Unit,
    private val onStatusChanged: (String) -> Unit
) {

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val SERVICE_UUID = UUID.fromString("4fafc201-1fb5-459e-8fcc-c5c9c331914b")
    private val CHAR_UUID = UUID.fromString("beb5483e-36e1-4688-b7f5-ea07361b26a8")
    private var bluetoothGatt: BluetoothGatt? = null

    fun startScan() {
        val scanner = bluetoothAdapter?.bluetoothLeScanner
        if (scanner == null) {
            onStatusChanged("BLUETOOTH OFF")
            return
        }

        onStatusChanged("SCANNING...")

        scanner.startScan(object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult?) {
                val device = result?.device ?: return
                val name = device.name ?: result.scanRecord?.deviceName ?: "Unknown"

                if (name == "MYOVOICE_GLOVE") {
                    scanner.stopScan(this)
                    onStatusChanged("FOUND: $name")
                    connectToDevice(device)
                }
            }

            override fun onScanFailed(errorCode: Int) {
                onStatusChanged("SCAN FAILED: $errorCode")
            }
        })
    }

    private fun connectToDevice(device: BluetoothDevice) {
        onStatusChanged("CONNECTING...")
        bluetoothGatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    onStatusChanged("CONNECTED")
                    gatt?.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    onStatusChanged("DISCONNECTED")
                    bluetoothGatt?.close()
                }
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
                val characteristic = gatt?.getService(SERVICE_UUID)?.getCharacteristic(CHAR_UUID)
                if (characteristic != null) {
                    gatt.setCharacteristicNotification(characteristic, true)
                    val descriptor = characteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                    descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    gatt.writeDescriptor(descriptor)
                }
            }

            override fun onCharacteristicChanged(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?) {
                characteristic?.value?.let { bytes ->
                    // Correct conversion for text data
                    val text = String(bytes, Charsets.UTF_8)
                    val cleanHex = if (text.startsWith("0x")) text else "0x$text"
                    Handler(Looper.getMainLooper()).post { onDataReceived(cleanHex) }
                }
            }
        })
    }

    // --- NEW: Allows manual disconnection for the toggle button ---
    fun disconnect() {
        if (bluetoothGatt != null) {
            bluetoothGatt?.disconnect()
            bluetoothGatt?.close()
            bluetoothGatt = null
            onStatusChanged("DISCONNECTED (USER)")
        }
    }
}