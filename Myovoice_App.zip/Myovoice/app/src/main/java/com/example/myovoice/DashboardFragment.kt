package com.example.myovoice

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.myovoice.databinding.FragmentDashboardBinding
import org.json.JSONObject
import java.util.Locale

class DashboardFragment : Fragment(), TextToSpeech.OnInitListener {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private lateinit var bleHelper: BleHelper
    private var tts: TextToSpeech? = null
    private val terminalLogs = StringBuilder("> System Ready_\n")
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        prefs = requireContext().getSharedPreferences("MyoVoiceConfig", Context.MODE_PRIVATE)
        tts = TextToSpeech(requireContext(), this)
        bleHelper = BleHelper(requireContext(),
            onDataReceived = { hex -> handleIncomingData(hex) },
            onStatusChanged = { status ->
                activity?.runOnUiThread {
                    binding.tvStatus.text = "STATUS: $status"

                    if (status == "CONNECTED") {
                        binding.tvStatus.setTextColor(Color.GREEN)
                        binding.btnScan.text = "DISCONNECT" // Change button to Red stop button
                        binding.btnScan.setBackgroundColor(Color.RED)
                    } else {
                        if (status.contains("DISCONNECTED")) {
                            binding.tvStatus.setTextColor(Color.RED)
                            binding.btnScan.text = "INITIATE_SCAN" // Change back to Scan
                            binding.btnScan.setBackgroundColor(Color.parseColor("#00f3ff")) // Cyan
                        }
                    }
                }
            }
        )

        // TOGGLE BUTTON LOGIC
        binding.btnScan.setOnClickListener {
            val currentText = binding.btnScan.text.toString()

            if (currentText == "INITIATE_SCAN") {
                appendToTerminal("Starting Connection...")
                bleHelper.startScan()
            } else {
                appendToTerminal("Disconnecting...")
                bleHelper.disconnect()
            }
        }

        // NEW BUTTON: Opens the Protocol Matrix
        binding.btnMatrix.setOnClickListener {
            val intent = Intent(requireContext(), ProtocolActivity::class.java)
            startActivity(intent)
        }
    }

    private fun handleIncomingData(hexCode: String) {
        activity?.runOnUiThread {
            // FIX: Capital X Issue.
            val cleanHex = hexCode.trim().uppercase().replace("0X", "0x")

            binding.tvReceivedHex.text = "INPUT: $cleanHex"

            // LOAD DATABASE
            val savedJson = prefs.getString("gesture_map", "{}")
            val json = JSONObject(savedJson)

            if (json.has(cleanHex)) {
                // ROBUST FIX: Check if it's the new format (Object) or old format (String)
                val rawData = json.opt(cleanHex)

                var mode = "TTS"
                var action = "Unknown"

                if (rawData is JSONObject) {
                    // New Format: {"mode": "...", "action": "..."}
                    mode = rawData.optString("mode", "TTS")
                    action = rawData.optString("action", "No Action")
                } else if (rawData is String) {
                    // Old Format: "Turn on lights" (Legacy Support)
                    action = rawData
                    mode = if (action.lowercase().contains("lights")) "ASSISTANT" else "TTS"
                }

                binding.tvMappedGesture.text = "DETECTED: $action"
                binding.tvMappedGesture.setTextColor(Color.GREEN)
                binding.tvProtocol.text = "MODE: $mode"

                executeAction(mode, action)
            } else {
                binding.tvMappedGesture.text = "UNKNOWN"
                binding.tvMappedGesture.setTextColor(Color.RED)
            }
        }
    }

    private fun executeAction(mode: String, action: String) {
        if (mode == "TTS") {
            appendToTerminal("Speaking: $action")
            tts?.speak(action, TextToSpeech.QUEUE_FLUSH, null, null)
        } else if (mode == "ASSISTANT") {
            appendToTerminal("Triggering Assistant: $action")
            triggerAssistant(action)
        }
    }

    private fun triggerAssistant(command: String) {
        try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH)
            intent.putExtra(SearchManager.QUERY, command)
            startActivity(intent)
        } catch (e: Exception) {
            appendToTerminal("Assistant Error: ${e.message}")
        }
    }

    private fun appendToTerminal(msg: String) {
        terminalLogs.append("\n> $msg")
        binding.tvTerminal.text = terminalLogs.toString()
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US }
    override fun onDestroyView() { super.onDestroyView(); tts?.shutdown(); _binding = null }
}