package com.example.myovoice

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class ProtocolActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var tableLayout: TableLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_protocol)

        prefs = getSharedPreferences("MyoVoiceConfig", Context.MODE_PRIVATE)

        // Locate views based on the NEW XML
        tableLayout = findViewById(R.id.tableProtocols)
        val etHexInput = findViewById<EditText>(R.id.etHex)
        val btnQuickAdd = findViewById<Button>(R.id.btnQuickAdd)
        val btnSaveTable = findViewById<Button>(R.id.btnSaveTable)

        // 1. Quick Add Logic
        btnQuickAdd.setOnClickListener {
            val raw = etHexInput.text.toString().trim().uppercase()
            if (raw.isNotEmpty()) {
                val hex = if (raw.startsWith("0X")) raw.replace("0X", "0x") else "0x$raw"
                saveSingleItem(hex, "TTS", "New Gesture")
                etHexInput.text.clear()
                refreshTable()
            }
        }

        // 2. Save All Logic
        btnSaveTable.setOnClickListener {
            saveTableData()
        }

        // 3. Load Data
        checkAndInitializeDefaults()
        refreshTable()
    }

    private fun refreshTable() {
        tableLayout.removeAllViews()

        val json = JSONObject(prefs.getString("gesture_map", "{}"))
        val sortedKeys = json.keys().asSequence().sorted().toList()

        for (key in sortedKeys) {
            val item = json.getJSONObject(key)
            val mode = item.optString("mode", "TTS")
            val action = item.optString("action", "")
            addTableRow(key, mode, action)
        }
    }

    private fun addTableRow(hex: String, mode: String, action: String) {
        val row = TableRow(this)
        row.setPadding(0, 10, 0, 10)
        row.gravity = Gravity.CENTER_VERTICAL

        // HEX Column
        val tvHex = TextView(this)
        tvHex.text = hex
        tvHex.setTextColor(Color.CYAN)
        tvHex.textSize = 16f
        tvHex.setPadding(10, 0, 10, 0)
        row.addView(tvHex)

        // MODE Column (Button)
        val btnMode = Button(this, null, android.R.attr.buttonStyleSmall)
        btnMode.text = mode
        btnMode.textSize = 12f
        if (mode == "ASSISTANT") {
            btnMode.setBackgroundColor(Color.parseColor("#8B008B")) // Purple
            btnMode.setTextColor(Color.WHITE)
        } else {
            btnMode.setBackgroundColor(Color.parseColor("#21262d")) // Dark Gray
            btnMode.setTextColor(Color.GREEN)
        }
        btnMode.setOnClickListener {
            if (btnMode.text == "TTS") {
                btnMode.text = "ASSISTANT"
                btnMode.setBackgroundColor(Color.parseColor("#8B008B"))
                btnMode.setTextColor(Color.WHITE)
            } else {
                btnMode.text = "TTS"
                btnMode.setBackgroundColor(Color.parseColor("#21262d"))
                btnMode.setTextColor(Color.GREEN)
            }
        }
        row.addView(btnMode)

        // ACTION Column (Input)
        val etAction = EditText(this)
        etAction.setText(action)
        etAction.setTextColor(Color.WHITE)
        etAction.background = null
        etAction.hint = "Action..."
        etAction.setPadding(20, 0, 0, 0)
        row.addView(etAction)

        tableLayout.addView(row)
    }

    private fun saveTableData() {
        val newJson = JSONObject()
        for (i in 0 until tableLayout.childCount) {
            val row = tableLayout.getChildAt(i) as TableRow
            val tvHex = row.getChildAt(0) as TextView
            val btnMode = row.getChildAt(1) as Button
            val etAction = row.getChildAt(2) as EditText

            val entry = JSONObject()
            entry.put("mode", btnMode.text.toString())
            entry.put("action", etAction.text.toString())
            newJson.put(tvHex.text.toString(), entry)
        }
        prefs.edit().putString("gesture_map", newJson.toString()).apply()
        Toast.makeText(this, "All Changes Saved!", Toast.LENGTH_SHORT).show()
    }

    private fun saveSingleItem(key: String, mode: String, action: String) {
        val json = JSONObject(prefs.getString("gesture_map", "{}"))
        val entry = JSONObject()
        entry.put("mode", mode)
        entry.put("action", action)
        json.put(key, entry)
        prefs.edit().putString("gesture_map", json.toString()).apply()
    }

    private fun checkAndInitializeDefaults() {
        val currentMap = prefs.getString("gesture_map", "{}")
        if (currentMap == "{}" || JSONObject(currentMap).length() < 5) {
            val json = JSONObject()
            for (i in 1..50) {
                val hexKey = "0x" + "%02X".format(i)
                val entry = JSONObject()
                entry.put("mode", "TTS")
                entry.put("action", "Gesture $i")
                json.put(hexKey, entry)
            }
            prefs.edit().putString("gesture_map", json.toString()).apply()
        }
    }
}